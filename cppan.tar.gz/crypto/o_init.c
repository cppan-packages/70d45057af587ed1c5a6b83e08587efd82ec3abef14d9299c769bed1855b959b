/* $OpenBSD$ */
/* Ted Unangst places this file in the public domain. */

#include <openssl/crypto.h>

void
OPENSSL_init(void)
{

}
